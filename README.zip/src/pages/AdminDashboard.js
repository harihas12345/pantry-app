import React from 'react';
import AddItemForm from '../forms/AddItemForm';
import PublicPantryView from './PublicPantryView';

const AdminDashboard = ({ user, signOut }) => (
  <div style={{ padding: 20 }}>
    <h2>Welcome, {user?.username || 'Admin'} 👋</h2>
    <button onClick={signOut} style={{ marginBottom: '1rem' }}>Sign Out</button>
    <h3>Admin Pantry Dashboard</h3>
    <AddItemForm />
    <PublicPantryView />
  </div>
);

export default AdminDashboard;
