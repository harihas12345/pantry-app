// index.js or main.jsx
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

import { Amplify } from 'aws-amplify';
import awsExports from './aws-exports'; // This should be auto-generated
import '@aws-amplify/ui-react/styles.css';

Amplify.configure(awsExports); // ✅ THIS IS CRITICAL

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);

